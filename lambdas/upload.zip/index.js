const multipart = require('aws-lambda-multipart-parser')

exports.handler = async (event) => {
    console.log(multipart.parse(event))
    const response = {
        statusCode: 200,
        body: event.body
    };
    return response;
};
